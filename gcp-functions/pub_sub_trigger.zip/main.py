import base64
import json
import requests
import random
import google.cloud.functions.context as context

# AWS Lambda API endpoint
API_ENDPOINT = 'https://qfkguno2uf.execute-api.us-east-1.amazonaws.com/default/gcptoaws'
AGENTS = ["agent1@example.com", "agent2@example.com", "agent3@example.com"]

def process_message(event, context):
    """
    Processes a Pub/Sub message, assigns it to a property agent, and forwards it to an AWS Lambda function.
    """
    try:
        # Decode the Pub/Sub message
        pubsub_message = base64.b64decode(event['data']).decode('utf-8')
        message_data = json.loads(pubsub_message)

        # Log message data
        print(f"Received message: {message_data}")

        # Randomly select a property agent
        agent_email = random.choice(AGENTS)
        message_data['assigned_agent'] = agent_email

        # Prepare data to send to AWS Lambda
        payload = {
            "body": message_data
        }
        print(f"Payload to send to AWS Lambda: {payload}")

        # Send POST request to AWS Lambda endpoint
        response = requests.post(API_ENDPOINT, json=payload)
        if response.status_code == 200:
            print('Message successfully forwarded to AWS Lambda')
        else:
            print(f'Failed to forward message to AWS Lambda: {response.text}')
            print(response)

        # Forward to a random property agent (simplified example)
        send_email_to_agent(agent_email, message_data)

    except json.JSONDecodeError as json_error:
        print(f'Error decoding JSON message: {json_error}')
    except requests.exceptions.RequestException as req_error:
        print(f'Error sending request to AWS Lambda: {req_error}')
    except Exception as e:
        print(f'An unexpected error occurred: {e}')

def send_email_to_agent(agent_email, message_data):
    """
    Simulates sending an email to a property agent.
    """
    try:
        # Implementing email sending logic here
        print(f"Sending email to {agent_email} with data: {message_data}")
    except Exception as e:
        print(f'An error occurred while sending email to {agent_email}: {e}')
