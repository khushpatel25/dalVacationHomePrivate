const { DynamoDBClient, PutItemCommand } = require("@aws-sdk/client-dynamodb");
const { v4: uuidv4 } = require("uuid");

const dynamodbClient = new DynamoDBClient({ region: "us-east-1" });

exports.handler = async (event) => {
    console.log("Event: ", event);
    
    const { roomId, userId, startDate, endDate } = event;

    if (!roomId || !userId || !startDate || !endDate) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: "Missing required parameters" }),
        };
    }

    const reservationId = uuidv4();

    const reservationParams = {
        TableName: "reservationDetails",
        Item: {
            reservationId: { S: reservationId },
            roomId: { S: roomId },
            userId: { S: userId },
            startDate: { S: startDate },
            endDate: { S: endDate },
            createdAt: { S: new Date().toISOString() },
            updatedAt: { S: new Date().toISOString() },
        },
    };

    try {
        await dynamodbClient.send(new PutItemCommand(reservationParams));

        return {
            statusCode: 200,
            body: JSON.stringify({ message: "Room reserved successfully.", reservationId, userId }),
        };
    } catch (error) {
        console.error('Error while reserving the room:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' }),
        };
    }
};
